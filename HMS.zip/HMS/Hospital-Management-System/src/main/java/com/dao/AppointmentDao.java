package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.entity.Appointment;
import com.entity.Doctor;
import com.mysql.cj.protocol.Resultset;

public class AppointmentDao {

	private Connection conn;

	public AppointmentDao(Connection conn) {
		super();
		this.conn = conn;
	}

	public boolean addAppointment(Appointment ap) {
		boolean f = false;

		try {

			String sql = "insert into appointment(user_id, fullname, gender, age, appoint_date, email, phno, diseases, doctor_id, address, status) values(?,?,?,?,?,?,?,?,?,?,?)";

			PreparedStatement ps = conn.prepareStatement(sql);

			ps.setInt(1, ap.getUserId());
			ps.setString(2, ap.getFullName());
			ps.setString(3, ap.getGender());
			ps.setString(4, ap.getAge());
			ps.setString(5, ap.getAppoinDate());
			ps.setString(6, ap.getEmail());
			ps.setString(7, ap.getPhno());
			ps.setString(8, ap.getDiseases());
			ps.setInt(9, ap.getDoctorId());
			ps.setString(10, ap.getAddress());
			ps.setString(11, ap.getStatus());

			int i = ps.executeUpdate();

			if (i == 1) {
				f = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}

	public List<Appointment> getAllAppointmentByLoginUser(int userId) {
		List<Appointment> list = new ArrayList<Appointment>();
		Appointment ap = null;

		try {
			String sql = "select * from appointment where user_id=?";

			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, userId);
			Resultset rs = (Resultset) ps.executeQuery();

			while (((ResultSet) rs).next()) {
				ap = new Appointment();
				ap.setId(((ResultSet) rs).getInt(1));
				ap.setUserId(((ResultSet) rs).getInt(2));
				ap.setFullName(((ResultSet) rs).getString(3));
				ap.setGender(((ResultSet) rs).getString(4));
				ap.setAge(((ResultSet) rs).getString(5));
				ap.setAppoinDate(((ResultSet) rs).getString(6));
				ap.setEmail(((ResultSet) rs).getString(7));
				ap.setPhno(((ResultSet) rs).getString(8));
				ap.setDiseases(((ResultSet) rs).getString(9));
				ap.setDoctorId(((ResultSet) rs).getInt(10));
				ap.setAddress(((ResultSet) rs).getString(11));
				ap.setStatus(((ResultSet) rs).getString(12));
				list.add(ap);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}

	public List<Appointment> getAllAppointmentByDoctorLogin(int doctorId) {
		List<Appointment> list = new ArrayList<Appointment>();
		Appointment ap = null;

		try {
			String sql = "select * from appointment where doctor_id=?";

			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, doctorId);
			Resultset rs = (Resultset) ps.executeQuery();

			while (((ResultSet) rs).next()) {
				ap = new Appointment();
				ap.setId(((ResultSet) rs).getInt(1));
				ap.setUserId(((ResultSet) rs).getInt(2));
				ap.setFullName(((ResultSet) rs).getString(3));
				ap.setGender(((ResultSet) rs).getString(4));
				ap.setAge(((ResultSet) rs).getString(5));
				ap.setAppoinDate(((ResultSet) rs).getString(6));
				ap.setEmail(((ResultSet) rs).getString(7));
				ap.setPhno(((ResultSet) rs).getString(8));
				ap.setDiseases(((ResultSet) rs).getString(9));
				ap.setDoctorId(((ResultSet) rs).getInt(10));
				ap.setAddress(((ResultSet) rs).getString(11));
				ap.setStatus(((ResultSet) rs).getString(12));
				list.add(ap);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}

	public Appointment getAppointmentById(int id) {

		Appointment ap = null;

		try {
			String sql = "select * from appointment where id=?";

			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			Resultset rs = (Resultset) ps.executeQuery();

			while (((ResultSet) rs).next()) {
				ap = new Appointment();
				ap.setId(((ResultSet) rs).getInt(1));
				ap.setUserId(((ResultSet) rs).getInt(2));
				ap.setFullName(((ResultSet) rs).getString(3));
				ap.setGender(((ResultSet) rs).getString(4));
				ap.setAge(((ResultSet) rs).getString(5));
				ap.setAppoinDate(((ResultSet) rs).getString(6));
				ap.setEmail(((ResultSet) rs).getString(7));
				ap.setPhno(((ResultSet) rs).getString(8));
				ap.setDiseases(((ResultSet) rs).getString(9));
				ap.setDoctorId(((ResultSet) rs).getInt(10));
				ap.setAddress(((ResultSet) rs).getString(11));
				ap.setStatus(((ResultSet) rs).getString(12));

			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return ap;
	}

	public boolean updateCommentStatus(int id, int doctid, String comm) {
		boolean f = false;

		try {
			String sql = "update appointment set status=? where id=? and doctor_id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, comm);
			ps.setInt(2, id);
			ps.setInt(3, doctid);
			
			int i = ps.executeUpdate();
			if(i == 1)
			{
				f=true;
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return f;

	}
	
	
	public List<Appointment> getAllAppointment() {
		List<Appointment> list = new ArrayList<Appointment>();
		Appointment ap = null;

		try {
			String sql = "select * from appointment order by id desc";

			PreparedStatement ps = conn.prepareStatement(sql);
			
			Resultset rs = (Resultset) ps.executeQuery();

			while (((ResultSet) rs).next()) {
				ap = new Appointment();
				ap.setId(((ResultSet) rs).getInt(1));
				ap.setUserId(((ResultSet) rs).getInt(2));
				ap.setFullName(((ResultSet) rs).getString(3));
				ap.setGender(((ResultSet) rs).getString(4));
				ap.setAge(((ResultSet) rs).getString(5));
				ap.setAppoinDate(((ResultSet) rs).getString(6));
				ap.setEmail(((ResultSet) rs).getString(7));
				ap.setPhno(((ResultSet) rs).getString(8));
				ap.setDiseases(((ResultSet) rs).getString(9));
				ap.setDoctorId(((ResultSet) rs).getInt(10));
				ap.setAddress(((ResultSet) rs).getString(11));
				ap.setStatus(((ResultSet) rs).getString(12));
				list.add(ap);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
}
